package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnGeoFenceSettingListener {
    void onGeoFenceSet(String geoFenceCenter, double geoFenceDiameter);
}

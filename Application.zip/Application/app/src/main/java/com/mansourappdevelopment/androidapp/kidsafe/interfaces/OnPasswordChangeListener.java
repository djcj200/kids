package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnPasswordChangeListener {
	void onPasswordChange(String newPassword);
}

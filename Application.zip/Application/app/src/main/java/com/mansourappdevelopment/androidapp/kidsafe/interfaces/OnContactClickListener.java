package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnContactClickListener {

    void onCallClick(String contactNumber);

    void onMessageClick(String contactNumber);
}

package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnPasswordResetListener {
    void onOkClicked(String email);

    void onCancelClicked();
}

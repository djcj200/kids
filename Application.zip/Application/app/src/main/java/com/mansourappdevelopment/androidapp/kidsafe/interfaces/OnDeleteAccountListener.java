package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnDeleteAccountListener {
	void onDeleteAccount(String password);
}
